export const loginSelectors = {
  username: '[data-test="username"]',
  password: '[data-test="password"]',
  loginButton: '[data-test="login-button"]'
};

export const inventorySelectors = {
  inventoryItem: '.inventory_item',
  cartLink: '.shopping_cart_link'
};

export const cartSelectors = {
  checkoutButton: '[data-test="checkout"]'
};

export const checkoutSelectors = {
  firstName: '[data-test="firstName"]',
  lastName: '[data-test="lastName"]',
  postalCode: '[data-test="postalCode"]',
  continueButton: '[data-test="continue"]',
  finishButton: '[data-test="finish"]'
};

export const checkoutCompleteSelectors = {
  confirmationMessage: '.complete-header'
};
