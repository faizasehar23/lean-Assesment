import loginPage from '../pageObjects/loginPage';
import inventoryPage from '../pageObjects/inventoryPage';
import cartPage from '../pageObjects/cartPage';
import checkoutPage from '../pageObjects/checkoutPage';
import checkoutCompletePage from '../pageObjects/checkoutCompletePage';

describe('E2E Checkout Flow with Assertions - SauceDemo', () => {
  let testData;

  before(() => {
    cy.fixture('testData').then(data => {
      testData = data;
    });
  });

  it('should login, add 3 items, assert cart & checkout details, and complete order', () => {
    loginPage.visit();
    loginPage.login(testData.username, testData.password);

    inventoryPage.addRandomItems(3);

    // Wait for alias from `addRandomItems`
    cy.get('@selectedItems').then((selectedItems) => {
      inventoryPage.goToCart();
      cartPage.verifyCartItems(selectedItems);
      cartPage.goToCheckout();

      checkoutPage.fillInformation(
        testData.firstName,
        testData.lastName,
        testData.postalCode
      );

      checkoutPage.verifyOverviewPage(selectedItems);
      checkoutPage.finishCheckout();

      checkoutCompletePage.verifyOrderSuccess();
    });
  });
});
