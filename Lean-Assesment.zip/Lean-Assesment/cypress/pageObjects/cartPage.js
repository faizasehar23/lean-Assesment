import { cartSelectors } from '../Selectors/selectors';

class CartPage {
  verifyCartItems(expectedItems) {
    cy.get('.cart_item').should('have.length', expectedItems.length);

    expectedItems.forEach((item, index) => {
      cy.get('.cart_item').eq(index).within(() => {
        cy.get('.inventory_item_name').should('have.text', item.name);
        cy.get('.inventory_item_price').should('have.text', item.price);
      });
    });
  }
  
  goToCheckout() {
    cy.get(cartSelectors.checkoutButton).click();
  }
}

export default new CartPage();
