import { checkoutSelectors } from '../Selectors/selectors';

class CheckoutPage {
  fillInformation(firstName, lastName, zip) {
    cy.get(checkoutSelectors.firstName).type(firstName);
    cy.get(checkoutSelectors.lastName).type(lastName);
    cy.get(checkoutSelectors.postalCode).type(zip);
    cy.get(checkoutSelectors.continueButton).click();
  }

  verifyOverviewPage(expectedItems) {
  // ✅ Item Name & Price Check
  cy.get('.cart_item').should('have.length', expectedItems.length);
  expectedItems.forEach((item, index) => {
    cy.get('.cart_item').eq(index).within(() => {
      cy.get('.inventory_item_name').should('have.text', item.name);
      cy.get('.inventory_item_price').should('have.text', item.price);
    });
  });

  // ✅ Calculate and assert item total
  const itemTotal = expectedItems.reduce((sum, item) => {
    return sum + parseFloat(item.price.replace('$', ''));
  }, 0);

  cy.get('.summary_subtotal_label').should('contain', `Item total: $${itemTotal.toFixed(2)}`);
   cy.get('.summary_tax_label').invoke('text').then(taxText => {
    const tax = parseFloat(taxText.replace('Tax: $', ''));

    cy.get('.summary_total_label').invoke('text').then(totalText => {
      const total = parseFloat(totalText.replace('Total: $', ''));
      const expectedTotal = +(itemTotal + tax).toFixed(2); // force precision

      expect(total).to.equal(expectedTotal);
    });
  });
    // Payment & Shipping Info
     cy.contains('Payment Information:')
    .next()
    .should('contain', 'SauceCard');
    cy.scrollTo('bottom');  // or 'top', 'center'
    cy.contains('.summary_info_label', 'Shipping Information:')
  .next('.summary_value_label')
  .should('contain', 'Free Pony Express Delivery!');


  }

  finishCheckout() {
    cy.get(checkoutSelectors.finishButton).click();
  }
}

export default new CheckoutPage();
