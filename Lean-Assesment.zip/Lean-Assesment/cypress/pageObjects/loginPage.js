import { loginSelectors } from '../Selectors/selectors';

class LoginPage {
  visit() {
    cy.visit('https://www.saucedemo.com/');
  }

  login(username, password) {
    cy.get(loginSelectors.username).type(username);
    cy.get(loginSelectors.password).type(password);
    cy.get(loginSelectors.loginButton).click();
  }
}

export default new LoginPage();
