import { inventorySelectors } from '../Selectors/selectors';

class InventoryPage {
  addRandomItems(count) {
    cy.get(inventorySelectors.inventoryItem).then(items => {
      const indices = Cypress._.sampleSize([...Array(items.length).keys()], count);
      const selected = [];

      indices.forEach(index => {
        const item = items[index];
        const itemName = item.querySelector('.inventory_item_name').textContent;
        const itemPrice = item.querySelector('.inventory_item_price').textContent;
        selected.push({ name: itemName, price: itemPrice });
        cy.wrap(item).find('button').click();
      });

      // Store selected items as alias
      cy.wrap(selected).as('selectedItems');
    });
  }

  goToCart() {
    cy.get(inventorySelectors.cartLink).click();
  }
}

export default new InventoryPage();
