import { checkoutCompleteSelectors } from '../Selectors/selectors';

class CheckoutCompletePage {
  verifyOrderSuccess() {
    cy.get(checkoutCompleteSelectors.confirmationMessage)
      .should('contain', 'Thank you for your order');
       cy.get('.complete-text').should(
      'contain',
      'Your order has been dispatched, and will arrive just as fast as the pony can get there!'
    );
  }
  
}

export default new CheckoutCompletePage();
